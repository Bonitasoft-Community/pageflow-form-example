(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customChangePageButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function ChangePageButton($scope) {
    $scope.changePage = function() {
        if (!angular.isNumber($scope.properties.pageId))
            throw 'ChangePageButton: "Page id" parameter not a number';
        
        if ($scope.properties.pageAction == 'Next')
            $scope.properties.pageId ++;
        else
            $scope.properties.pageId --;
    };
},
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        type="button"\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="changePage()"\n        ng-disabled="properties.disabled">{{ properties.label | uiTranslate }}</button>\n</div>'
    };
  });
